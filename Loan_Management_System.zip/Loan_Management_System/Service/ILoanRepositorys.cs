﻿//using Loan_Management_System.Model;
//using System;
//using System.Collections.Generic;

//namespace Loan_Management_System.Service
//{
//    public interface ILoanRepositorys
//    {
//        // Method to apply a loan
//        bool ApplyLoan(Loan loan);

//        // Method to calculate interest for a loan by loanId
//        decimal CalculateInterest(int loanId);

//        // Overloaded method to calculate interest using loan parameters
//        decimal CalculateInterest(decimal principalAmount, decimal interestRate, int loanTerm);

//        // Method to check and update loan status based on credit score
//        void LoanStatus(int loanId);

//        // Method to calculate EMI by loanId
//        decimal CalculateEMI(int loanId);

//        // Overloaded method to calculate EMI using loan parameters
//        decimal CalculateEMI(decimal principalAmount, decimal interestRate, int loanTerm);

//        // Method to handle loan repayment
//        void LoanRepayment(int loanId, decimal amount);

//        // Method to get all loans
//        List<Loan> GetAllLoans();

//        // Method to get a loan by ID
//        Loan GetLoanById(int loanId);
//        decimal CalculateInterest(decimal principal);
//    }
//}
