﻿using System;
using System.Collections.Generic;
using System.Linq;
using Loan_Management_System.Model;
using Loan_Management_System.Repository;

namespace Loan_Management_System.Service
{
    public class ILoanRepositoryImpl : ILoanRepository
    {
        private List<Loan> loans = new List<Loan>(); 

       
        public bool ApplyLoan(Loan loan)
        {
            Console.WriteLine("Do you want to apply for this loan? (Yes/No)");
            string userInput = Console.ReadLine();

            if (userInput.ToLower() == "yes")
            {
                loan.LoanStatus = "Pending";  
                loans.Add(loan);  
                Console.WriteLine("Loan applied successfully.");
                return true;
            }

            Console.WriteLine("Loan application canceled.");
            return false;
        }

      
        public decimal CalculateInterest(int loanId)
        {
            Loan loan = loans.FirstOrDefault(l => l.LoanID == loanId);
            if (loan == null)
                throw new Exception("Invalid loan ID");

            return CalculateInterest(loan.PrincipalAmount, loan.InterestRate, loan.LoanTerm);
        }

       
        public decimal CalculateInterest(decimal principalAmount, decimal interestRate, int loanTerm)
        {
            return (principalAmount * interestRate * loanTerm) / 12;
        }

        // Check and update loan status based on credit score
        public void LoanStatus(int loanId)
        {
            Loan loan = loans.FirstOrDefault(l => l.LoanID == loanId);
            if (loan == null)
                throw new Exception("Loan not found");

            // For simplicity, assume we have access to the customer's credit score
            int customerCreditScore = 700;  // Example static value, in a real scenario this should come from the customer data

            if (customerCreditScore >= 650)
            {
                loan.LoanStatus = "Approved";
                Console.WriteLine("Loan approved.");
            }
            else
            {
                loan.LoanStatus = "Rejected";
                Console.WriteLine("Loan rejected due to low credit score.");
            }
        }

        // Calculate EMI by loanId
        public decimal CalculateEMI(int loanId)
        {
            Loan loan = loans.FirstOrDefault(l => l.LoanID == loanId);
            if (loan == null)
                throw new Exception("Invalid loan ID");

            return CalculateEMI(loan.PrincipalAmount, loan.InterestRate, loan.LoanTerm);
        }

        // Overloaded method to calculate EMI using loan parameters
        public decimal CalculateEMI(decimal principalAmount, decimal interestRate, int loanTerm)
        {
            decimal r = interestRate / 12 / 100;  // Monthly interest rate
            int n = loanTerm;  // Loan term in months

            return (principalAmount * r * (decimal)Math.Pow((double)(1 + r), n)) / ((decimal)Math.Pow((double)(1 + r), n) - 1);
        }

        // Handle loan repayment
        public void LoanRepayment(int loanId, decimal amount)
        {
            Loan loan = loans.FirstOrDefault(l => l.LoanID == loanId);
            if (loan == null)
                throw new Exception("Loan not found");

            decimal emiAmount = CalculateEMI(loan.LoanID);  // Get EMI for this loan
            int noOfEMI = (int)(amount / emiAmount);  // Calculate number of EMIs that can be paid

            if (noOfEMI == 0)
            {
                Console.WriteLine($"Insufficient amount. EMI amount is {emiAmount}.");
                return;
            }

            loan.LoanStatus = "Paid";
            Console.WriteLine($"Loan repayment successful. {noOfEMI} EMI(s) paid.");
        }

        // Get all loans
        public List<Loan> GetAllLoans()
        {
            return loans;
        }

        // Get loan by ID
        public Loan GetLoanById(int loanId)
        {
            Loan loan = loans.FirstOrDefault(l => l.LoanID == loanId);
            if (loan == null)
                throw new Exception("Loan not found");
            return loan;
        }

        public decimal CalculateInterest(decimal principal)
        {
            throw new NotImplementedException();
        }
    }
}
