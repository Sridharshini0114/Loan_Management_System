﻿using System;
using Loan_Management_System.Service;
using Loan_Management_System.Model;
using Loan_Management_System.Repository;

namespace Loan_Management_System
{
    class Program
    {
        static void Main(string[] args)
        {
            ILoanRepository loanRepository = new LoanRepository(); // Assuming LoanRepository is implemented
            LoanService loanService = new LoanService(loanRepository);

            bool exit = false;

            while (!exit)
            {
                Console.WriteLine("\nLoan Management System");
                Console.WriteLine("1. Apply Loan");
                Console.WriteLine("2. Get All Loans");
                Console.WriteLine("3. Get Loan by ID");
                Console.WriteLine("4. Loan Repayment");
                Console.WriteLine("5. Exit");
                Console.Write("Choose an option: ");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        ApplyLoan(loanService);
                        break;
                    case "2":
                        GetAllLoans(loanService);
                        break;
                    case "3":
                        GetLoanById(loanService);
                        break;
                    case "4":
                        LoanRepayment(loanService);
                        break;
                    case "5":
                        exit = true;
                        Console.WriteLine("Exiting Loan Management System. Goodbye!");
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }

        static void ApplyLoan(LoanService loanService)
        {
            try
            {
                Console.WriteLine("\nEnter Loan Details");
                Console.Write("Customer ID: ");
                int customerId = int.Parse(Console.ReadLine());

                Console.Write("Principal Amount: ");
                decimal principalAmount = decimal.Parse(Console.ReadLine());

                Console.Write("Interest Rate: ");
                decimal interestRate = decimal.Parse(Console.ReadLine());

                Console.Write("Loan Term (months): ");
                int loanTerm = int.Parse(Console.ReadLine());

                Console.Write("Loan Type (CarLoan/HomeLoan): ");
                string loanType = Console.ReadLine();

                Console.Write("Loan Status (Pending/Approved): ");
                string loanStatus = Console.ReadLine();

                Console.Write("Credit Score: ");
                int creditScore = int.Parse(Console.ReadLine());

                Loan loan = new Loan
                {
                    CustomerID = customerId,
                    PrincipalAmount = principalAmount,
                    InterestRate = interestRate,
                    LoanTerm = loanTerm,
                    LoanType = loanType,
                    LoanStatus = loanStatus,
                    CreditScore = creditScore
                };

                bool result = loanService.ApplyLoan(loan);
                Console.WriteLine(result ? "Loan application submitted successfully." : "Loan application failed.");
            }
            catch (FormatException ex)
            {
                Console.WriteLine("Invalid input. Please enter data in the correct format.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }

        static void GetAllLoans(LoanService loanService)
        {
            Console.WriteLine("\nAll Loans:");
            var loans = loanService.GetAllLoans();
            foreach (var loan in loans)
            {
                loan.PrintLoanInfo();
            }
        }

        static void GetLoanById(LoanService loanService)
        {
            try
            {
                Console.Write("\nEnter Loan ID: ");
                int loanId = int.Parse(Console.ReadLine());

                var loan = loanService.GetLoanById(loanId);
                if (loan != null)
                {
                    loan.PrintLoanInfo();
                }
                else
                {
                    Console.WriteLine("Loan not found.");
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid input. Please enter a numeric value.");
            }
        }

        static void LoanRepayment(LoanService loanService)
        {
            try
            {
                Console.Write("\nEnter Loan ID: ");
                int loanId = int.Parse(Console.ReadLine());

                Console.Write("Enter Repayment Amount: ");
                decimal repaymentAmount = decimal.Parse(Console.ReadLine());

                loanService.LoanRepayment(loanId, repaymentAmount);
                Console.WriteLine("Loan repayment processed successfully.");
            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid input. Please enter numeric values.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }
    }
}
