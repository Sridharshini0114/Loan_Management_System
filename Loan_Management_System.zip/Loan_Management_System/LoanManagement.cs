﻿using Loan_Management_System.Model;
using Loan_Management_System.Service;
using System;
using System.Collections.Generic;

namespace Loan_Management_System
{
    public class LoanManagement
    {
        private readonly LoanService _loanService;

        public LoanManagement(LoanService loanService)
        {
            _loanService = loanService ?? throw new ArgumentNullException(nameof(loanService), "LoanService cannot be null");
        }

        // Method to apply a loan
        public bool ApplyLoan(int customerId, decimal principalAmount, decimal interestRate, int loanTerm, string loanType, string loanStatus)
        {
            Loan loan = new Loan
            {
                CustomerID = customerId,
                PrincipalAmount = principalAmount,
                InterestRate = interestRate,
                LoanTerm = loanTerm,
                LoanType = loanType,
                LoanStatus = loanStatus
            };

            bool isSuccess = _loanService.ApplyLoan(loan);
            return isSuccess;
        }

        // Method to get all loans
        public List<Loan> GetAllLoans()
        {
            return _loanService.GetAllLoans();
        }

        // Method to get a loan by ID
        public Loan GetLoanById(int loanId)
        {
            return _loanService.GetLoanById(loanId);
        }

        // Method to handle loan repayment
        public void LoanRepayment(int loanId, decimal repaymentAmount)
        {
            _loanService.LoanRepayment(loanId, repaymentAmount);
        }

        // Method to display the loan details in a user-friendly way
        public void DisplayLoanDetails(Loan loan)
        {
            if (loan != null)
            {
                Console.WriteLine("Loan ID: " + loan.LoanID);
                Console.WriteLine("Customer ID: " + loan.CustomerID);
                Console.WriteLine("Principal Amount: " + loan.PrincipalAmount);
                Console.WriteLine("Interest Rate: " + loan.InterestRate);
                Console.WriteLine("Loan Term (months): " + loan.LoanTerm);
                Console.WriteLine("Loan Type: " + loan.LoanType);
                Console.WriteLine("Loan Status: " + loan.LoanStatus);
                Console.WriteLine("----------------------------");
            }
            else
            {
                Console.WriteLine("Loan not found.");
            }
        }

        // Method to handle loan status update based on conditions (e.g., credit score, etc.)
        public void UpdateLoanStatusBasedOnCreditScore(int loanId, int customerCreditScore)
        {
            Loan loan = _loanService.GetLoanById(loanId);
            if (loan != null)
            {
                if (customerCreditScore >= 650)
                {
                    loan.LoanStatus = "Approved";
                    Console.WriteLine("Loan approved based on credit score.");
                }
                else
                {
                    loan.LoanStatus = "Rejected";
                    Console.WriteLine("Loan rejected due to low credit score.");
                }
            }
            else
            {
                Console.WriteLine("Loan not found for ID: " + loanId);
            }
        }

        // Example method to calculate EMI for a loan
        public decimal CalculateEMI(int loanId)
        {
            Loan loan = _loanService.GetLoanById(loanId);
            if (loan != null)
            {
                return _loanService.CalculateEMI(loan.LoanID);
            }
            else
            {
                Console.WriteLine("Loan not found.");
                return 0;
            }
        }

        // Method to calculate interest for a loan by loanId
        public decimal CalculateInterest(int loanId)
        {
            Loan loan = _loanService.GetLoanById(loanId);
            if (loan != null)
            {
                return _loanService.CalculateInterest(loan.LoanID);
            }
            else
            {
                Console.WriteLine("Loan not found.");
                return 0;
            }
        }
    }
}
